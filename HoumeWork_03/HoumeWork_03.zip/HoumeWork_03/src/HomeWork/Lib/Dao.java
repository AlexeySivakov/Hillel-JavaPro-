package HomeWork.Lib;

public @interface Dao {

}
