package HomeWork.Lib;

public @interface Inject {

}
