package Lib;

public @interface Dao {

}
