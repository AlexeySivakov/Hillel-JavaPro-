package Lib;

public @interface Inject {

}
