package Alishev.Alishev_05;

public class ForLoop {
    public static void main(String[] args) {
        for (int i = 10; i >= 0; i = i - 5) {
            System.out.println("Hello " + i);
        }
    }
}
