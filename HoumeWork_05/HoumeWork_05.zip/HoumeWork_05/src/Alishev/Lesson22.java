package Alishev;

public class Lesson22 {
    public static void main(String[] args) {
        final int X = 10;
        System.out.println(X);
        //X = 5;
    }
}

class Test{
    public final int CONSTANT;
    public static final int CONSTANT2 = 0;
    public Test(int CONSTANT) {
        this.CONSTANT = CONSTANT;
    }
}
