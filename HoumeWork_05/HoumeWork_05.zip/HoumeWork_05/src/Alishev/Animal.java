package Alishev;

public class Animal {
    String name =  "Some name";

    public void eat(){
        System.out.println("I`m eating!");
    }

    public void sleep(){
        System.out.println("I`m sleeping!");
    }
}
