package Alishev;

public class Lesson23_end {
    public static void main(String[] args) {
        System.out.printf("String %10d \n",532);
        System.out.printf("String %10d \n",53244);
        System.out.printf("String %10d \n",5324546);
        System.out.printf("String %10d \n",532567775);
        System.out.printf("String %.2f \n",45.32444);
        System.out.printf("String %.2f \n",45.3756744);
        System.out.printf("String %.2f \n",45.32456756744);
        System.out.printf("String %.2f \n",45.356756744);
        System.out.printf("String %.2f \n",45.365744);
    }
}
