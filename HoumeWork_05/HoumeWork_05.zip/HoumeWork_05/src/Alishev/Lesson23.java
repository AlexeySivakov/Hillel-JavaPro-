package Alishev;

public class Lesson23 {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder("Hello");
        System.out.println(sb);
        sb.append(" my");
        sb.append(" friend");
        System.out.println(sb);
        StringBuilder sb2 = new StringBuilder("Hello");
        System.out.println(sb2);
        sb2.append(" my").append(" friend");
        System.out.println(sb2);
    }
}
